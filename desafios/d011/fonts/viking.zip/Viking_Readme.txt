Hi!

You�ve found one of DeNada Industries� many typefaces.

I hope you like them!

This is shareware. I�m asking for a measly $10 for each computer you put the font on and ONLY if you use it. If you don�t use it, don�t send me anything! Sound simple? If you're going to use the font commercially (or you plan to put it on more than five computers), e-mail me and we can discuss bulk discounting.

If you wanna include this in some collection, or on your website, that�s cool. Please let me know. If you can give me a copy of the CD that�d be even better. You MUST include this readme file though. It�s important. Otherwise you�re nothing but a dang pirate and pirates can go hang!

Send the shareware fee to me here: 
Mike Allard
2006 NW 53rd Ave, #F12
Gainesville, FL 32653

Cash is fine, just wrap it in a piece of paper and let me be surprised when I open the envelope. I love surprises.

I also accept PayPal payments.

My many typefaces include:
AlfredDrake
Grauman
EBrantScript
Heather
JoePerry
Juliet (See also Romeo)
KellyAnnGothic
KellyBrown
KrtRussell
LaurenScript
MachineScript
MissBrooks
PerryGothic
Romeo (see also Juliet)
SumDumGoi
Viking
WillRobinson

If you are looking for some of the files listed above, just Google them. In addition to DaFont.com, I can recommend TypeOasis. (http://moorstation.org/typoasis/typoasis1.htm). It�s very well organized and they, too, have my full endorsement.

NOTE: If a font arrives in your hands without everything intact, tough beans. I don�t do support. 

If you wanna write and ask me questions, my e-mail address is Michael559@aol.com. Don�t be surprised if it takes me a little while to get back to you� e-mail may be faster than light, but I�m not� If you wanna write me and tell me that you just LOVE my typeface (or whatever) don�t. Just send me the shareware fee, then I�ll know you treasure it. Heck, if those nuns from Luxembourg can do it, so can you. You don�t have to send me a photo of your convent, though. On the other hand, it did make me smile and that�s never a bad thing.

After all that, please send that $10 to:
Mike Allard
2006 NW 53rd Ave, #F12
Gainesville, FL 32653


Thanks,
The Staff (Mike)
Michael559@aol.com